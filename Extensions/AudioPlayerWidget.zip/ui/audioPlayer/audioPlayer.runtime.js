﻿/*global Encoder,TW */

(function () {
    var addedDefaultButtonStyles = false;

    TW.Runtime.Widgets.audioPlayer = function () {
        var thisWidget = this;
        var roundedCorners = true;

        this.runtimeProperties = function () {
            return {
                'needsDataLoadingAndError': false,
                'propertyAttributes': {
                    'Label': {
                        'isLocalizable': true
                    }
                }

            };
        };

        this.renderHtml = function () {
            // The Disabled property is used for programmatic control of the button state. There is
            // also a class, widget-audioPlayer-disabled, which is used internally to debounce button
            // click events.
			var audioFile = thisWidget.getProperty('AudioFileURL', false);

            var html =
                '<div class="widget-content widget-audioPlayer">'
					+ '<audio class="player_audio" src="' + audioFile + '" volume="1.0" controls="true"></audio>'  
                + '</div>';
            return html;
        };

        this.afterRender = function () {
            thisWidget.jqElement.bind('click', function (e) {
                // ignore clicks if button is disabled

                var isDisabled = widgetProperties.Disabled ||
                    thisWidget.jqElement.hasClass('widget-audioPlayer-disabled');

                if (!isDisabled) {
                    //TW.log.info('button enabled');
					$('.player_audio').trigger("play");
                } else {
                    //TW.log.info('button disabled');
                }
                e.preventDefault();
            });

        };
		
		this.serviceInvoked = function (serviceName) {
			//if (serviceName === 'Play') {
				$('.player_audio').trigger("play");
			//} 
		};
		
        this.beforeDestroy = function () {
            try {
                thisWidget.jqElement.unbind();
            } catch (err) {
                TW.log.error('Error in TW.Runtime.Widgets.audioPlayer.beforeDestroy', err);
            }
        };

        this.updateProperty = function (updatePropertyInfo) {
            if(updatePropertyInfo.TargetProperty === 'AudioFileURL') {
        	var url= updatePropertyInfo.SinglePropertyValue;
				if( url === undefined ) {
					url = '';
				}
				this.setProperty('AudioFileURL', url);
			}
        };
    };
}());
