﻿TW.IDE.Widgets.audioPlayer = function () {
	this.widgetIconUrl = function() {
        return  "../Common/extensions/audioPlayer/ui/audioPlayer/audioPlayer.ide.png";
    }
    this.widgetProperties = function () {
        return {
            'name': 'Audio Player',
            'description': 'Plays audio file on event',
            'category': ['Common'],
            'iconImage': 'audioPlayer.ide.png',
            'properties': {
                'Width': {
                    'description': 'width of widget',
                    'baseType': 'NUMBER',
                    'defaultValue': 300
                },
                'Height': {
                    'description': 'height of widget',
                    'baseType': 'NUMBER',
                    'defaultValue': 30,
                    'isEditable': false
                },
                'TabSequence': {
                    'description': 'Tab sequence index',
                    'baseType': 'NUMBER',
                    'defaultValue': 0
                },
				'AudioFileURL': {
                    'description': 'This URL will be used to define the location of the audio file.',
                    'baseType': 'STRING',
					'isBindingTarget': true,
					'defaultValue': 'http://localhost/Thingworx/default.mp3'
                }
            }
        };
    };
	
	this.widgetServices = function () {
        return {
            'Play': { 'warnIfNotBound': true }
        };
    };

    /* this.afterSetProperty = function (name, value) {
        var result = false;
        switch (name) {
            case 'Style':
            case 'Width':
            case 'Height':
                result = true;
                break;
            default:
                break;
        }
        return result;
    }; */


    this.renderHtml = function () {
        var html = '';

        html +=
            '<div class="widget-content widget-audioPlayer">'
			+ '<span>'
                + '<audio class="player_audio" src="' + '"http://localhost/Thingworx/default.mp3"' + '" controls="true"></audio>'  
			+ '</span>'
          + '</div>';
        return html;
    };
};